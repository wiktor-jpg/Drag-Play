import os
import re
import uuid
import tempfile
import threading
import time
from flask import Flask, request, jsonify, send_file
from flask_cors import CORS
import yt_dlp

app = Flask(__name__)
CORS(app, origins="*")

# Temporary storage for completed downloads
DOWNLOADS = {}  # job_id -> { status, file_path, filename, error }
LOCK = threading.Lock()

def cleanup_file(path, delay=300):
    """Delete file after 5 minutes"""
    def _delete():
        time.sleep(delay)
        try:
            if os.path.exists(path):
                os.remove(path)
        except:
            pass
    threading.Thread(target=_delete, daemon=True).start()

def do_download(job_id, url, fmt, quality):
    tmpdir = tempfile.mkdtemp()
    
    # Build yt-dlp format string
    if fmt == "MP3":
        ydl_opts = {
            "format": "bestaudio/best",
            "outtmpl": os.path.join(tmpdir, "%(title)s.%(ext)s"),
            "postprocessors": [{
                "key": "FFmpegExtractAudio",
                "preferredcodec": "mp3",
                "preferredquality": quality or "320",
            }],
            "quiet": True,
            "no_warnings": True,
        }
    elif fmt == "WAV":
        ydl_opts = {
            "format": "bestaudio/best",
            "outtmpl": os.path.join(tmpdir, "%(title)s.%(ext)s"),
            "postprocessors": [{
                "key": "FFmpegExtractAudio",
                "preferredcodec": "wav",
            }],
            "quiet": True,
            "no_warnings": True,
        }
    elif fmt == "FLAC":
        ydl_opts = {
            "format": "bestaudio/best",
            "outtmpl": os.path.join(tmpdir, "%(title)s.%(ext)s"),
            "postprocessors": [{
                "key": "FFmpegExtractAudio",
                "preferredcodec": "flac",
            }],
            "quiet": True,
            "no_warnings": True,
        }
    elif fmt == "AIFF":
        ydl_opts = {
            "format": "bestaudio/best",
            "outtmpl": os.path.join(tmpdir, "%(title)s.%(ext)s"),
            "postprocessors": [{
                "key": "FFmpegExtractAudio",
                "preferredcodec": "aiff",
            }],
            "quiet": True,
            "no_warnings": True,
        }
    elif fmt == "M4A":
        ydl_opts = {
            "format": "bestaudio[ext=m4a]/bestaudio/best",
            "outtmpl": os.path.join(tmpdir, "%(title)s.%(ext)s"),
            "quiet": True,
            "no_warnings": True,
        }
    else:  # OGG
        ydl_opts = {
            "format": "bestaudio/best",
            "outtmpl": os.path.join(tmpdir, "%(title)s.%(ext)s"),
            "postprocessors": [{
                "key": "FFmpegExtractAudio",
                "preferredcodec": "vorbis",
            }],
            "quiet": True,
            "no_warnings": True,
        }

    try:
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            info = ydl.extract_info(url, download=True)
            title = info.get("title", "track")

        # Find the downloaded file
        files = os.listdir(tmpdir)
        if not files:
            raise Exception("No file downloaded")
        
        filepath = os.path.join(tmpdir, files[0])
        filename = files[0]

        with LOCK:
            DOWNLOADS[job_id] = {
                "status": "done",
                "file_path": filepath,
                "filename": filename,
                "title": title,
            }
        
        cleanup_file(filepath)

    except Exception as e:
        with LOCK:
            DOWNLOADS[job_id] = {
                "status": "error",
                "error": str(e),
            }

@app.route("/health", methods=["GET"])
def health():
    return jsonify({"status": "ok", "service": "Drag&Play Backend"})

@app.route("/info", methods=["POST"])
def get_info():
    """Get track info (title, duration) without downloading"""
    data = request.json or {}
    url = data.get("url", "").strip()
    if not url:
        return jsonify({"error": "No URL provided"}), 400

    try:
        ydl_opts = {
            "quiet": True,
            "no_warnings": True,
            "extract_flat": False,
            "skip_download": True,
        }
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            info = ydl.extract_info(url, download=False)
        
        # Handle playlists
        if info.get("_type") == "playlist":
            entries = info.get("entries", [])
            tracks = []
            for e in entries:
                if e:
                    tracks.append({
                        "title": e.get("title", "Unknown"),
                        "url": e.get("webpage_url") or e.get("url", ""),
                        "duration": e.get("duration", 0),
                        "thumbnail": e.get("thumbnail", ""),
                    })
            return jsonify({
                "type": "playlist",
                "title": info.get("title", "Playlist"),
                "count": len(tracks),
                "tracks": tracks,
            })
        else:
            return jsonify({
                "type": "track",
                "title": info.get("title", "Unknown"),
                "duration": info.get("duration", 0),
                "thumbnail": info.get("thumbnail", ""),
                "uploader": info.get("uploader", ""),
            })
    except Exception as e:
        return jsonify({"error": str(e)}), 400

@app.route("/download", methods=["POST"])
def start_download():
    """Start async download, return job_id"""
    data = request.json or {}
    url = data.get("url", "").strip()
    fmt = data.get("format", "MP3").upper()
    quality = data.get("quality", "320")

    if not url:
        return jsonify({"error": "No URL provided"}), 400

    job_id = str(uuid.uuid4())
    with LOCK:
        DOWNLOADS[job_id] = {"status": "downloading"}

    thread = threading.Thread(
        target=do_download,
        args=(job_id, url, fmt, quality),
        daemon=True
    )
    thread.start()

    return jsonify({"job_id": job_id, "status": "downloading"})

@app.route("/status/<job_id>", methods=["GET"])
def check_status(job_id):
    """Poll download status"""
    with LOCK:
        job = DOWNLOADS.get(job_id)
    
    if not job:
        return jsonify({"error": "Job not found"}), 404
    
    if job["status"] == "done":
        return jsonify({
            "status": "done",
            "filename": job.get("filename"),
            "title": job.get("title"),
        })
    elif job["status"] == "error":
        return jsonify({
            "status": "error",
            "error": job.get("error"),
        })
    else:
        return jsonify({"status": "downloading"})

@app.route("/file/<job_id>", methods=["GET"])
def get_file(job_id):
    """Serve the downloaded file"""
    with LOCK:
        job = DOWNLOADS.get(job_id)
    
    if not job or job["status"] != "done":
        return jsonify({"error": "File not ready"}), 404
    
    filepath = job.get("file_path")
    filename = job.get("filename", "track.mp3")

    if not filepath or not os.path.exists(filepath):
        return jsonify({"error": "File not found"}), 404

    return send_file(
        filepath,
        as_attachment=True,
        download_name=filename,
    )

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 8080))
    app.run(host="0.0.0.0", port=port, debug=False)

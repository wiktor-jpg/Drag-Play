# Drag&Play — Backend

Flask + yt-dlp backend. Deploy na Railway.

## Endpoints
- GET  /health         — status
- POST /info           — info o tracku/playliście
- POST /download       — start pobierania, zwraca job_id
- GET  /status/:job_id — sprawdź status
- GET  /file/:job_id   — pobierz plik

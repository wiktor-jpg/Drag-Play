# Drag&Play — DJ Bulk Downloader

Drop links. Download everything. One click.

## Deploy na Vercel

1. Wgraj ten folder na GitHub
2. Wejdź na vercel.com → Import repo
3. Deploy — gotowe

## Lokalnie

```bash
npm install
npm start
```

## Stack
- React 18
- yt-dlp engine (symulacja frontend)
- Space Mono + Bebas Neue + Rubik

import { useState, useRef, useEffect, useCallback } from "react";

// ─── CSS ──────────────────────────────────────────────────────────────────────
const CSS = `
@import url('https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Space+Mono:ital,wght@0,400;0,700;1,400&family=Rubik:wght@400;500;700;900&display=swap');

*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
:root{
  --black:#080808;--dark:#111;--panel:#191919;--panel2:#212121;
  --border:#2e2e2e;--border2:#3d3d3d;--white:#f2f2f2;--muted:#777;
  --g:#c6f135;--pink:#ff2d78;--blue:#2de0ff;--orange:#ff6b1a;--yellow:#ffd600;
  --font-d:'Bebas Neue',sans-serif;--font-m:'Space Mono',monospace;--font-b:'Rubik',sans-serif;
}
body{background:var(--black);color:var(--white);font-family:var(--font-b);overflow-x:hidden}
::-webkit-scrollbar{width:3px}::-webkit-scrollbar-track{background:var(--dark)}::-webkit-scrollbar-thumb{background:var(--border2);border-radius:2px}

.wrap{min-height:100vh;background:var(--black);position:relative;overflow-x:hidden}
.grain{position:fixed;inset:0;opacity:.04;pointer-events:none;z-index:0;
  background-image:url("data:image/svg+xml,%3Csvg viewBox='0 0 512 512' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='.85' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)'/%3E%3C/svg%3E")}
.blob{position:fixed;border-radius:50%;filter:blur(80px);pointer-events:none;z-index:0}
.inner{position:relative;z-index:1;max-width:900px;margin:0 auto;padding:0 16px 80px}

/* HEADER */
.hdr{padding:24px 0 18px;display:flex;align-items:center;gap:14px;border-bottom:1px solid var(--border);margin-bottom:24px}
.hdr-txt{flex:1}
.appname{font-family:var(--font-d);font-size:clamp(28px,5.5vw,46px);letter-spacing:2px;line-height:1;color:var(--white)}
.appname em{color:var(--g);font-style:normal}
.apptag{font-family:var(--font-m);font-size:10px;color:var(--muted);margin-top:3px;text-transform:uppercase;letter-spacing:.14em}
.hdr-stats{display:flex;gap:10px;flex-shrink:0;flex-wrap:wrap}
.hpill{background:var(--panel);border:1px solid var(--border);border-radius:4px;padding:5px 11px;font-family:var(--font-m);font-size:9px;color:var(--muted);text-align:center;min-width:64px}
.hpill strong{display:block;font-size:17px;font-weight:700;line-height:1.15}
.hpill strong.g{color:var(--g)}.hpill strong.b{color:var(--blue)}.hpill strong.p{color:var(--pink)}

/* DROP ZONE */
.dz{border:2px dashed var(--border2);border-radius:10px;padding:36px 20px 28px;text-align:center;cursor:pointer;transition:all .2s;background:var(--panel);position:relative;overflow:hidden;margin-bottom:14px;min-height:170px;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:8px}
.dz::after{content:'';position:absolute;inset:0;background:linear-gradient(135deg,transparent 50%,rgba(198,241,53,.025));pointer-events:none}
.dz.over{border-color:var(--g);background:rgba(198,241,53,.05);box-shadow:0 0 40px rgba(198,241,53,.07) inset}
.dz.over .dzi{transform:scale(1.15) translateY(-4px)}
.dz.playlist{border-color:var(--blue);background:rgba(45,224,255,.04)}
.dzi{transition:transform .3s;font-size:48px;line-height:1}
.dzt{font-family:var(--font-d);font-size:clamp(20px,4vw,30px);letter-spacing:1px;color:var(--white)}
.dzs{font-family:var(--font-m);font-size:10px;color:var(--muted);text-transform:uppercase;letter-spacing:.1em}
.src-row{display:flex;justify-content:center;gap:6px;flex-wrap:wrap;margin-top:6px}
.src{display:inline-flex;align-items:center;gap:4px;background:var(--panel2);border:1px solid var(--border);border-radius:3px;padding:3px 9px;font-family:var(--font-m);font-size:9px;color:var(--muted);text-transform:uppercase;letter-spacing:.07em}
.src .dot{width:5px;height:5px;border-radius:50%;flex-shrink:0}
.pl-badge{background:rgba(45,224,255,.12);border:1px solid rgba(45,224,255,.3);color:var(--blue);padding:3px 10px;border-radius:3px;font-family:var(--font-m);font-size:9px;text-transform:uppercase;letter-spacing:.08em;margin-top:4px;display:inline-flex;align-items:center;gap:5px}

/* PLAYLIST BANNER */
.pl-banner{background:rgba(45,224,255,.06);border:1px solid rgba(45,224,255,.25);border-radius:6px;padding:10px 14px;margin-bottom:14px;display:flex;align-items:center;gap:10px;font-family:var(--font-m);font-size:11px;color:var(--blue)}
.pl-banner-icon{font-size:18px;flex-shrink:0}
.pl-banner-info{flex:1}
.pl-banner-title{font-weight:700;margin-bottom:2px}
.pl-banner-sub{font-size:9px;color:rgba(45,224,255,.6);text-transform:uppercase;letter-spacing:.08em}

/* PASTE AREA */
.paste{background:var(--panel);border:1px solid var(--border);border-radius:8px;margin-bottom:14px;overflow:hidden}
.paste-hdr{display:flex;align-items:center;justify-content:space-between;padding:9px 13px;border-bottom:1px solid var(--border);background:var(--panel2)}
.paste-lbl{font-family:var(--font-m);font-size:9px;color:var(--muted);text-transform:uppercase;letter-spacing:.1em}
.paste-ta{width:100%;min-height:80px;background:transparent;border:none;outline:none;resize:vertical;padding:11px 13px;font-family:var(--font-m);font-size:11px;color:var(--white);line-height:1.75}
.paste-ta::placeholder{color:var(--border2)}
.paste-foot{padding:7px 11px;border-top:1px solid var(--border);display:flex;justify-content:space-between;align-items:center;background:var(--panel2)}
.paste-foot-txt{font-family:var(--font-m);font-size:9px;color:var(--muted)}

/* FORMAT */
.fmt-row{display:flex;align-items:center;gap:6px;margin-bottom:14px;flex-wrap:wrap}
.fmt-lbl{font-family:var(--font-m);font-size:9px;color:var(--muted);text-transform:uppercase;letter-spacing:.1em;flex-shrink:0}
.fmtb{background:var(--panel2);border:1px solid var(--border);color:var(--muted);padding:4px 11px;font-family:var(--font-m);font-size:9px;border-radius:3px;cursor:pointer;transition:all .15s;text-transform:uppercase;letter-spacing:.05em}
.fmtb.on{background:var(--g);color:var(--black);border-color:var(--g);font-weight:700}
.fmtb:hover:not(.on){border-color:var(--border2);color:var(--white)}
.fmt-sep{width:1px;height:16px;background:var(--border);margin:0 4px}

/* BUTTONS */
.btn{display:inline-flex;align-items:center;gap:6px;border:none;cursor:pointer;font-family:var(--font-m);font-weight:700;transition:all .15s;border-radius:3px;text-transform:uppercase;letter-spacing:.06em}
.btn:active{transform:scale(.97)}
.btn-primary{background:var(--g);color:var(--black);padding:14px 28px;font-size:13px;border-radius:5px;letter-spacing:.08em}
.btn-primary:hover{background:#d9ff52}
.btn-primary:disabled{background:var(--border2);color:var(--muted);cursor:not-allowed}
.btn-ghost{background:transparent;border:1px solid var(--border);color:var(--muted);padding:6px 12px;font-size:9px}
.btn-ghost:hover{border-color:var(--border2);color:var(--white)}
.btn-danger{background:transparent;border:1px solid rgba(255,45,120,.3);color:var(--pink);padding:6px 12px;font-size:9px}
.btn-danger:hover{background:rgba(255,45,120,.08)}
.btn-sm{padding:4px 9px;font-size:8px}
.btn-blue{background:rgba(45,224,255,.1);border:1px solid rgba(45,224,255,.3);color:var(--blue);padding:14px 20px;font-size:12px;border-radius:5px}
.btn-blue:hover{background:rgba(45,224,255,.18)}

/* TOTAL BAR */
.total-bar{display:flex;gap:10px;margin-bottom:16px;flex-wrap:wrap}
.tstat{background:var(--panel);border:1px solid var(--border);border-radius:6px;padding:10px 14px;flex:1;min-width:100px}
.tstat-lbl{font-family:var(--font-m);font-size:9px;color:var(--muted);text-transform:uppercase;letter-spacing:.1em;margin-bottom:4px}
.tstat-val{font-family:var(--font-d);font-size:22px;letter-spacing:.5px;line-height:1;color:var(--white)}
.tstat-val.g{color:var(--g)}.tstat-val.b{color:var(--blue)}.tstat-val.y{color:var(--yellow)}

/* QUEUE CONTROLS */
.qctrl{display:flex;align-items:center;gap:8px;margin-bottom:10px;flex-wrap:wrap}
.qctrl-l{flex:1;display:flex;align-items:center;gap:8px}
.qtitle{font-family:var(--font-d);font-size:17px;letter-spacing:.5px;color:var(--white)}
.qcnt{font-family:var(--font-m);font-size:9px;background:var(--panel2);border:1px solid var(--border);color:var(--g);padding:2px 8px;border-radius:2px}

/* TRACKS */
.tracklist{display:flex;flex-direction:column;gap:5px;margin-bottom:18px}
.track{background:var(--panel);border:1px solid var(--border);border-radius:6px;padding:9px 13px;display:flex;align-items:center;gap:11px;position:relative;overflow:hidden;transition:border-color .2s}
.track::before{content:'';position:absolute;left:0;top:0;bottom:0;width:3px;background:var(--border2);transition:background .3s}
.track.s-queued::before{background:var(--border2)}
.track.s-analyzing::before{background:var(--yellow);animation:bp 1s ease-in-out infinite}
.track.s-downloading::before{background:var(--blue);animation:bp 1s ease-in-out infinite}
.track.s-done::before{background:var(--g)}
.track.s-error::before{background:var(--pink)}
@keyframes bp{0%,100%{opacity:1}50%{opacity:.3}}
.track-prog{position:absolute;bottom:0;left:0;height:2px;background:linear-gradient(90deg,var(--blue),var(--g));opacity:0;transition:width .4s}
.track.s-downloading .track-prog{opacity:1}
.t-plat{width:26px;height:26px;border-radius:4px;display:flex;align-items:center;justify-content:center;font-size:12px;flex-shrink:0;font-weight:700}
.t-info{flex:1;min-width:0}
.t-name{font-size:12px;font-weight:500;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;margin-bottom:2px;color:var(--white)}
.t-url{font-family:var(--font-m);font-size:9px;color:var(--muted);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.t-dur{font-family:var(--font-m);font-size:9px;color:var(--muted);flex-shrink:0;margin-left:2px}
.t-meta{display:flex;gap:5px;align-items:center;flex-shrink:0}
.tbadge{font-family:var(--font-m);font-size:8px;padding:2px 6px;border-radius:2px;text-transform:uppercase;font-weight:700;letter-spacing:.05em;white-space:nowrap}
.tbadge.bpm{background:rgba(45,224,255,.1);color:var(--blue);border:1px solid rgba(45,224,255,.2)}
.tbadge.key{background:rgba(255,214,0,.1);color:var(--yellow);border:1px solid rgba(255,214,0,.2)}
.tbadge.done{background:rgba(198,241,53,.1);color:var(--g);border:1px solid rgba(198,241,53,.2)}
.tbadge.err{background:rgba(255,45,120,.1);color:var(--pink);border:1px solid rgba(255,45,120,.2)}
.tbadge.dl{background:rgba(45,224,255,.08);color:var(--blue);border:1px solid rgba(45,224,255,.15)}
.tbadge.az{background:rgba(255,214,0,.08);color:var(--yellow);border:1px solid rgba(255,214,0,.15)}
.tbadge.q{background:var(--panel2);color:var(--muted);border:1px solid var(--border)}
.t-rm{background:transparent;border:none;color:var(--border2);cursor:pointer;font-size:15px;padding:1px;line-height:1;transition:color .15s;flex-shrink:0}
.t-rm:hover{color:var(--pink)}

/* DOWNLOAD ALL BTN (Big) */
.dl-all-btn{width:100%;padding:18px;font-size:15px;letter-spacing:.1em;justify-content:center;border-radius:6px;margin-bottom:10px;border:none;cursor:pointer;font-family:var(--font-m);font-weight:700;text-transform:uppercase;transition:all .15s;display:flex;align-items:center;gap:10px}
.dl-all-btn:active{transform:scale(.98)}

/* PROGRESS MODAL */
.modal-bg{position:fixed;inset:0;background:rgba(0,0,0,.88);z-index:100;display:flex;align-items:center;justify-content:center;padding:20px;backdrop-filter:blur(6px)}
.modal{background:var(--dark);border:1px solid var(--border2);border-radius:12px;width:100%;max-width:520px;padding:28px;position:relative}
.modal-title{font-family:var(--font-d);font-size:28px;letter-spacing:1px;color:var(--white);margin-bottom:4px}
.modal-sub{font-family:var(--font-m);font-size:10px;color:var(--muted);text-transform:uppercase;letter-spacing:.1em;margin-bottom:22px}
.modal-bigpct{font-family:var(--font-d);font-size:72px;letter-spacing:-1px;line-height:1;color:var(--g);margin-bottom:6px}
.modal-bar-track{height:8px;background:var(--panel2);border-radius:4px;overflow:hidden;margin-bottom:18px}
.modal-bar-fill{height:100%;background:linear-gradient(90deg,var(--g) 0%,var(--blue) 100%);border-radius:4px;transition:width .5s ease;position:relative}
.modal-bar-fill::after{content:'';position:absolute;top:0;right:0;bottom:0;width:30px;background:linear-gradient(90deg,transparent,rgba(255,255,255,.18));animation:shim 1.2s infinite}
@keyframes shim{from{opacity:0}50%{opacity:1}to{opacity:0}}
.modal-stats-row{display:grid;grid-template-columns:repeat(3,1fr);gap:10px;margin-bottom:20px}
.mstat{background:var(--panel);border:1px solid var(--border);border-radius:6px;padding:10px 12px;text-align:center}
.mstat-lbl{font-family:var(--font-m);font-size:8px;color:var(--muted);text-transform:uppercase;letter-spacing:.1em;margin-bottom:4px}
.mstat-val{font-family:var(--font-d);font-size:20px;color:var(--white);line-height:1}
.mstat-val.g{color:var(--g)}.mstat-val.b{color:var(--blue)}.mstat-val.y{color:var(--yellow)}
.modal-track-mini{display:flex;align-items:center;gap:8px;padding:8px 10px;background:var(--panel);border-radius:5px;margin-bottom:6px;max-height:220px;overflow-y:auto;flex-direction:column;gap:4px}
.mini-track{display:flex;align-items:center;gap:8px;width:100%;padding:5px 0}
.mini-dot{width:6px;height:6px;border-radius:50%;flex-shrink:0}
.mini-name{flex:1;font-size:11px;color:var(--white);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.mini-prog{font-family:var(--font-m);font-size:9px;flex-shrink:0}
.modal-time-row{display:flex;justify-content:space-between;align-items:flex-end;margin-bottom:18px}
.modal-eta{font-family:var(--font-m);font-size:11px;color:var(--muted)}
.modal-eta strong{color:var(--white);font-size:13px}
.modal-speed{font-family:var(--font-m);font-size:10px;color:var(--muted)}
.modal-cancel{width:100%;padding:12px;background:transparent;border:1px solid var(--border);color:var(--muted);cursor:pointer;font-family:var(--font-m);font-size:10px;text-transform:uppercase;letter-spacing:.1em;border-radius:4px;transition:all .15s}
.modal-cancel:hover{border-color:var(--pink);color:var(--pink)}
.modal-done-row{text-align:center;padding:10px 0}
.modal-done-icon{font-size:48px;margin-bottom:8px}
.modal-done-title{font-family:var(--font-d);font-size:32px;letter-spacing:1px;color:var(--g);margin-bottom:6px}
.modal-done-sub{font-family:var(--font-m);font-size:10px;color:var(--muted);text-transform:uppercase;letter-spacing:.1em;margin-bottom:20px}

/* EMPTY */
.empty{text-align:center;padding:36px 20px;border:1px dashed var(--border);border-radius:6px;margin-bottom:18px}
.empty-icon{font-size:34px;margin-bottom:8px;opacity:.35}
.empty-txt{font-family:var(--font-m);font-size:10px;color:var(--muted);text-transform:uppercase;letter-spacing:.1em}

/* NOTIF */
.notif-wrap{position:fixed;top:16px;right:16px;display:flex;flex-direction:column;gap:5px;z-index:999;max-width:280px}
.notif{background:var(--panel2);border:1px solid var(--border);border-radius:4px;padding:9px 13px;font-family:var(--font-m);font-size:10px;color:var(--white);display:flex;align-items:center;gap:7px;animation:ni .2s ease;border-left-width:2px}
@keyframes ni{from{opacity:0;transform:translateX(8px)}}
.notif.ok{border-left-color:var(--g)}.notif.err{border-left-color:var(--pink)}.notif.info{border-left-color:var(--blue)}

/* TABS */
.tabs{display:flex;border-bottom:1px solid var(--border);margin-bottom:18px}
.tab{background:transparent;border:none;border-bottom:2px solid transparent;color:var(--muted);cursor:pointer;font-family:var(--font-m);font-size:9px;text-transform:uppercase;letter-spacing:.1em;padding:7px 14px;margin-bottom:-1px;transition:all .15s}
.tab.on{color:var(--g);border-bottom-color:var(--g)}
.tab:hover:not(.on){color:var(--white)}

.footer{margin-top:40px;padding-top:16px;border-top:1px solid var(--border);display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px}
.footer span{font-family:var(--font-m);font-size:9px;color:var(--border2)}

@media(max-width:560px){.hdr{flex-wrap:wrap}.hdr-stats{width:100%}.modal-stats-row{grid-template-columns:1fr 1fr}.total-bar{gap:6px}}
`;

// ─── HELPERS ──────────────────────────────────────────────────────────────────
function detectPlatform(url) {
  if (/youtu\.?be/.test(url)) return { name:"YouTube",  icon:"▶", color:"#ff3e3e", bg:"rgba(255,62,62,.15)"  };
  if (/soundcloud/.test(url)) return { name:"SoundCloud",icon:"◉", color:"#ff6b1a", bg:"rgba(255,107,26,.15)" };
  if (/bandcamp/.test(url))   return { name:"Bandcamp",  icon:"◈", color:"#2de0ff", bg:"rgba(45,224,255,.15)" };
  if (/tiktok/.test(url))     return { name:"TikTok",    icon:"♪", color:"#ff2d78", bg:"rgba(255,45,120,.15)" };
  if (/mixcloud/.test(url))   return { name:"Mixcloud",  icon:"≋", color:"#ffd600", bg:"rgba(255,214,0,.15)"  };
  if (/spotify/.test(url))    return { name:"Spotify",   icon:"●", color:"#c6f135", bg:"rgba(198,241,53,.15)" };
  return                               { name:"URL",       icon:"↗", color:"#888",    bg:"rgba(136,136,136,.1)" };
}

function isPlaylistURL(url) {
  return /list=/.test(url) || /\/sets\//.test(url) || /\/playlist/.test(url) || /\/album/.test(url);
}

// Simulate how many tracks a playlist might have
function estimatePlaylistTracks(url) {
  if (/list=/.test(url)) return Math.floor(Math.random()*30+10); // YT playlist 10-40
  if (/\/sets\//.test(url)) return Math.floor(Math.random()*20+5);
  return Math.floor(Math.random()*12+4);
}

function extractTitle(url, idx=0) {
  try {
    const u = new URL(url);
    if (u.hostname.includes("youtu")) {
      const v = u.searchParams.get("v");
      return `Track ${String(idx+1).padStart(2,"0")} — YouTube${v?" ("+v.slice(0,8)+")":""}`;
    }
    const parts = u.pathname.split("/").filter(Boolean);
    if (parts.length >= 2) return `${parts[parts.length-2]} — ${parts[parts.length-1]}`.replace(/-/g," ");
    return parts[0] || u.hostname;
  } catch { return `Track ${idx+1}`; }
}

function parseURLs(text) {
  const rx = /https?:\/\/[^\s,\n"'<>]+/g;
  return [...new Set(text.match(rx)||[])];
}

const KEYS = ["1A","2A","3A","4A","5A","6A","7A","8A","9A","10A","11A","12A","1B","2B","3B","4B","5B","6B","7B","8B","9B","10B","11B","12B"];
const randBPM = () => Math.floor(Math.random()*60+100);
const randKey = () => KEYS[Math.floor(Math.random()*KEYS.length)];

// Random duration 2min to 9min in seconds
const randDuration = () => Math.floor(Math.random()*420+120);

function fmtDur(s) {
  const m = Math.floor(s/60), sec = s%60;
  return `${m}:${String(sec).padStart(2,"0")}`;
}
function fmtDurLong(s) {
  const h = Math.floor(s/3600), m = Math.floor((s%3600)/60);
  if (h>0) return `${h}h ${m}m`;
  return `${m}m ${s%60}s`;
}

// Estimate download time: ~3-8 sec per track for MP3, more for WAV/FLAC
function estimateDownloadTime(count, fmt, qual) {
  const base = fmt==="MP3" ? (qual==="320" ? 5 : qual==="192" ? 4 : 3)
              : fmt==="WAV" ? 9 : fmt==="FLAC" ? 8 : 10;
  const total = count * base; // seconds
  if (total < 60) return `~${total}s`;
  const m = Math.ceil(total/60);
  return `~${m} min`;
}

function etaString(remaining, elapsed, done, total) {
  if (done === 0 || total === 0) return "Calculating…";
  const rate = done / elapsed; // tracks per second
  const left = remaining / rate;
  if (!isFinite(left)) return "Calculating…";
  const m = Math.floor(left/60), s = Math.floor(left%60);
  if (m > 0) return `${m}m ${s}s remaining`;
  return `${s}s remaining`;
}

// ─── LOGO ─────────────────────────────────────────────────────────────────────
function Logo({ size=52 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 60 60" fill="none" xmlns="http://www.w3.org/2000/svg" style={{flexShrink:0}}>
      {/* outer square frame — tag style */}
      <rect x="2" y="2" width="56" height="56" rx="6" fill="#111" stroke="#2e2e2e" strokeWidth="1.5"/>
      {/* spray paint backdrop green blob */}
      <ellipse cx="30" cy="31" rx="22" ry="20" fill="rgba(198,241,53,0.08)"/>
      {/* D shape — block graffiti letter */}
      <path d="M14 16 H24 Q40 16 40 30 Q40 44 24 44 H14 Z" fill="none" stroke="#c6f135" strokeWidth="3" strokeLinejoin="round"/>
      <path d="M20 22 H24 Q34 22 34 30 Q34 38 24 38 H20 Z" fill="#c6f135" opacity=".12"/>
      {/* inner D cutout line */}
      <path d="M20 22 V38" stroke="#c6f135" strokeWidth="2.5" strokeLinecap="round"/>
      {/* arrow inside D = download metaphor */}
      <path d="M27 27 L27 33 M27 33 L24 30 M27 33 L30 30" stroke="#c6f135" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"/>
      {/* spray dots — graffiti drips */}
      <circle cx="44" cy="18" r="2" fill="#2de0ff" opacity=".8"/>
      <circle cx="47" cy="22" r="1.2" fill="#2de0ff" opacity=".5"/>
      <circle cx="46" cy="15" r="1" fill="#2de0ff" opacity=".4"/>
      <circle cx="16" cy="47" r="1.8" fill="#ff2d78" opacity=".7"/>
      <circle cx="13" cy="50" r="1.1" fill="#ff2d78" opacity=".4"/>
      <circle cx="48" cy="46" r="1" fill="#c6f135" opacity=".5"/>
      {/* underline tag */}
      <path d="M10 51 Q30 49 50 51" stroke="#c6f135" strokeWidth="1" opacity=".3" strokeLinecap="round"/>
    </svg>
  );
}

// ─── NOTIFICATION ─────────────────────────────────────────────────────────────
function Notifs({ list }) {
  return <div className="notif-wrap">{list.map(n=>(
    <div key={n.id} className={`notif ${n.type}`}>
      <span>{n.type==="ok"?"✓":n.type==="err"?"✕":"·"}</span>{n.msg}
    </div>
  ))}</div>;
}

// ─── PROGRESS MODAL ───────────────────────────────────────────────────────────
function ProgressModal({ tracks, onCancel, startTime, isComplete, onClose }) {
  const total = tracks.length;
  const done = tracks.filter(t=>t.status==="done").length;
  const errors = tracks.filter(t=>t.status==="error").length;
  const active = tracks.filter(t=>t.status==="downloading"||t.status==="analyzing");
  const pct = total===0 ? 0 : Math.round((done/total)*100);
  const elapsed = (Date.now()-startTime)/1000;
  const remaining = total-done;
  const totalSecs = tracks.reduce((a,t)=>(t.duration||0)+a,0);

  const statusColor = (s) => s==="done"?"#c6f135":s==="downloading"?"#2de0ff":s==="error"?"#ff2d78":s==="analyzing"?"#ffd600":"#3d3d3d";

  return (
    <div className="modal-bg" onClick={e=>{ if(isComplete && e.target===e.currentTarget) onClose(); }}>
      <div className="modal">
        {!isComplete ? (
          <>
            <div className="modal-title">Downloading</div>
            <div className="modal-sub">Hang tight · yt-dlp engine running</div>
            <div className="modal-bigpct">{pct}%</div>
            <div className="modal-bar-track">
              <div className="modal-bar-fill" style={{width:`${pct}%`}} />
            </div>
            <div className="modal-stats-row">
              <div className="mstat"><div className="mstat-lbl">Done</div><div className="mstat-val g">{done}</div></div>
              <div className="mstat"><div className="mstat-lbl">Remaining</div><div className="mstat-val b">{remaining}</div></div>
              <div className="mstat"><div className="mstat-lbl">Errors</div><div className="mstat-val" style={{color:errors>0?"#ff2d78":"#555"}}>{errors}</div></div>
            </div>
            <div className="modal-time-row">
              <div className="modal-eta">
                ETA: <strong>{etaString(remaining, elapsed, done, total)}</strong>
              </div>
              <div className="modal-speed" style={{fontFamily:"var(--font-m)",fontSize:9,color:"var(--muted)"}}>
                {active.length} active · {done+errors}/{total} processed
              </div>
            </div>
            {/* mini track list */}
            <div style={{background:"var(--panel)",borderRadius:5,padding:"8px 10px",marginBottom:14,maxHeight:180,overflowY:"auto"}}>
              {tracks.map(t=>(
                <div key={t.id} className="mini-track">
                  <div className="mini-dot" style={{background:statusColor(t.status)}} />
                  <div className="mini-name" style={{fontFamily:"var(--font-m)",fontSize:10,color:"var(--white)"}}>{t.title}</div>
                  <div className="mini-prog" style={{fontFamily:"var(--font-m)",fontSize:9,color:"var(--muted)"}}>
                    {t.status==="done"?"✓":t.status==="error"?"✕":t.status==="downloading"?`${t.progress}%`:t.status==="analyzing"?"…":"—"}
                  </div>
                </div>
              ))}
            </div>
            <button className="modal-cancel" onClick={onCancel}>✕ Cancel download</button>
          </>
        ) : (
          <div className="modal-done-row">
            <div className="modal-done-icon">⬇</div>
            <div className="modal-done-title">Download complete!</div>
            <div className="modal-done-sub">{done} tracks · {errors>0?`${errors} failed · `:""}{totalSecs>0?fmtDurLong(totalSecs)+" of music":""}</div>
            <div className="modal-stats-row" style={{marginBottom:20}}>
              <div className="mstat"><div className="mstat-lbl">Downloaded</div><div className="mstat-val g">{done}</div></div>
              <div className="mstat"><div className="mstat-lbl">Total time</div><div className="mstat-val b">{totalSecs>0?fmtDurLong(totalSecs):"—"}</div></div>
              <div className="mstat"><div className="mstat-lbl">Failed</div><div className="mstat-val" style={{color:errors>0?"#ff2d78":"#555"}}>{errors}</div></div>
            </div>
            <button className="btn btn-primary" style={{width:"100%",justifyContent:"center",fontSize:12,padding:"14px"}} onClick={onClose}>
              → Back to queue
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

// ─── MAIN ─────────────────────────────────────────────────────────────────────
export default function DragPlay() {
  const [tracks, setTracks] = useState([]);
  const [paste, setPaste] = useState("");
  const [over, setOver] = useState(false);
  const [fmt, setFmt] = useState("MP3");
  const [qual, setQual] = useState("320");
  const [running, setRunning] = useState(false);
  const [showModal, setShowModal] = useState(false);
  const [modalComplete, setModalComplete] = useState(false);
  const [startTime, setStartTime] = useState(null);
  const [tab, setTab] = useState("queue");
  const [history, setHistory] = useState([]);
  const [notifs, setNotifs] = useState([]);
  const [totalAll, setTotalAll] = useState(0);
  const [playlistBanner, setPlaylistBanner] = useState(null);
  const cancelRef = useRef(false);

  useEffect(()=>{
    (async()=>{
      try{ const r=await window.storage.get("dp2-hist"); if(r) setHistory(JSON.parse(r.value)); }catch{}
      try{ const r=await window.storage.get("dp2-total"); if(r) setTotalAll(JSON.parse(r.value)); }catch{}
    })();
  },[]);

  const addNotif = useCallback((msg,type="info")=>{
    const id=Date.now()+Math.random();
    setNotifs(n=>[...n,{id,msg,type}]);
    setTimeout(()=>setNotifs(n=>n.filter(x=>x.id!==id)),3400);
  },[]);

  const addURLs = useCallback((urls)=>{
    const valid = urls.filter(u=>{ try{new URL(u);return true}catch{return false} });
    if(!valid.length){ addNotif("No valid URLs detected","err"); return; }

    const newTracks = [];
    let playlistDetected = null;

    valid.forEach((url,i)=>{
      // Detect playlist URL — expand into multiple fake tracks
      if(isPlaylistURL(url)){
        const count = estimatePlaylistTracks(url);
        const plat = detectPlatform(url);
        playlistDetected = { url, count, platform: plat.name };
        for(let j=0;j<count;j++){
          const fakeId = url + "_" + j;
          if(tracks.some(t=>t.url===fakeId)) continue;
          newTracks.push({
            id: Date.now()+Math.random()+j*0.001,
            url: fakeId,
            title: `${plat.name} Playlist — Track ${String(j+1).padStart(2,"0")}`,
            platform: plat,
            status: "queued",
            progress: 0,
            bpm: null, key: null,
            duration: randDuration(),
            fromPlaylist: url,
          });
        }
      } else {
        if(tracks.some(t=>t.url===url)) return;
        newTracks.push({
          id: Date.now()+Math.random()+i*0.001,
          url,
          title: extractTitle(url, i),
          platform: detectPlatform(url),
          status: "queued",
          progress: 0,
          bpm: null, key: null,
          duration: randDuration(),
          fromPlaylist: null,
        });
      }
    });

    if(!newTracks.length){ addNotif("All URLs already in queue","err"); return; }
    setTracks(t=>[...t,...newTracks]);

    if(playlistDetected){
      setPlaylistBanner(playlistDetected);
      addNotif(`Playlist detected — ${playlistDetected.count} tracks added!`,"ok");
    } else {
      addNotif(`${newTracks.length} track${newTracks.length>1?"s":""} added`,"ok");
    }
  },[tracks,addNotif]);

  const handleDrop = (e)=>{
    e.preventDefault(); setOver(false);
    const text = e.dataTransfer.getData("text/plain")||e.dataTransfer.getData("text/uri-list");
    if(text){ const u=parseURLs(text); if(u.length){ addURLs(u); return; } }
    addNotif("Drop a link or text with URLs","info");
  };

  const handleZoneClick = ()=>{
    const url=prompt("Paste a URL (single track, playlist, SoundCloud set…)");
    if(url){ addURLs(parseURLs(url)); }
  };

  const handlePasteAdd = ()=>{
    addURLs(parseURLs(paste));
    setPaste("");
  };

  const simulateOne = async (track)=>{
    if(cancelRef.current) return false;
    setTracks(t=>t.map(x=>x.id===track.id?{...x,status:"analyzing",progress:0}:x));
    await new Promise(r=>setTimeout(r,400+Math.random()*400));
    if(cancelRef.current) return false;

    setTracks(t=>t.map(x=>x.id===track.id?{...x,status:"downloading",progress:0}:x));
    for(let p=8;p<=92;p+=Math.floor(Math.random()*18+8)){
      if(cancelRef.current) return false;
      await new Promise(r=>setTimeout(r,150+Math.random()*250));
      setTracks(t=>t.map(x=>x.id===track.id?{...x,progress:Math.min(p,95)}:x));
    }
    await new Promise(r=>setTimeout(r,200));
    if(cancelRef.current) return false;

    const fail = Math.random()<0.08;
    if(fail){
      setTracks(t=>t.map(x=>x.id===track.id?{...x,status:"error",progress:0}:x));
      return false;
    }
    setTracks(t=>t.map(x=>x.id===track.id?{...x,status:"done",progress:100,bpm:randBPM(),key:randKey()}:x));
    return true;
  };

  const startAll = async ()=>{
    const queued = tracks.filter(t=>t.status==="queued"||t.status==="error");
    if(!queued.length){ addNotif("No tracks to download","err"); return; }
    cancelRef.current = false;
    setRunning(true);
    setModalComplete(false);
    setShowModal(true);
    setStartTime(Date.now());

    let done=0;
    // Run 3 in parallel
    const chunks=[];
    for(let i=0;i<queued.length;i+=3) chunks.push(queued.slice(i,i+3));
    for(const chunk of chunks){
      if(cancelRef.current) break;
      const results = await Promise.all(chunk.map(t=>simulateOne(t)));
      done += results.filter(Boolean).length;
    }

    setRunning(false);
    setModalComplete(true);

    const doneCount = tracks.filter(t=>t.status==="done").length + done;
    const newHist = [{date:new Date().toLocaleDateString(),count:done,fmt,qual},...history].slice(0,60);
    setHistory(newHist);
    setTotalAll(td=>{ const next=td+done; window.storage.set("dp2-total",JSON.stringify(next)).catch(()=>{}); return next; });
    window.storage.set("dp2-hist",JSON.stringify(newHist)).catch(()=>{});
  };

  const cancelDownload = ()=>{
    cancelRef.current=true;
    setRunning(false);
    setShowModal(false);
    setTracks(t=>t.map(x=>x.status==="downloading"||x.status==="analyzing"?{...x,status:"queued",progress:0}:x));
    addNotif("Download cancelled","err");
  };

  const removeTrack = id=>setTracks(t=>t.filter(x=>x.id!==id));
  const clearDone = ()=>setTracks(t=>t.filter(x=>x.status!=="done"));
  const clearAll = ()=>{ setTracks([]); setPlaylistBanner(null); addNotif("Queue cleared","info"); };

  const queued = tracks.filter(t=>t.status==="queued").length;
  const done   = tracks.filter(t=>t.status==="done").length;
  const errors = tracks.filter(t=>t.status==="error").length;
  const downloading = tracks.filter(t=>t.status==="downloading"||t.status==="analyzing").length;
  const totalDuration = tracks.reduce((a,t)=>(t.duration||0)+a,0);
  const queuedCount = tracks.filter(t=>t.status==="queued"||t.status==="error").length;
  const pctTotal = tracks.length===0?0:Math.round((done/tracks.length)*100);

  return (
    <>
      <style>{CSS}</style>
      <Notifs list={notifs} />

      {showModal && (
        <ProgressModal
          tracks={tracks}
          onCancel={cancelDownload}
          startTime={startTime||Date.now()}
          isComplete={modalComplete}
          onClose={()=>{ setShowModal(false); setModalComplete(false); }}
        />
      )}

      <div className="wrap">
        <div className="grain" />
        <div className="blob" style={{width:500,height:500,background:"rgba(198,241,53,.025)",top:-150,right:-120}} />
        <div className="blob" style={{width:350,height:350,background:"rgba(255,45,120,.025)",bottom:50,left:-100}} />
        <div className="blob" style={{width:280,height:280,background:"rgba(45,224,255,.02)",top:"35%",right:40}} />

        <div className="inner">

          {/* HEADER */}
          <header className="hdr">
            <Logo size={52} />
            <div className="hdr-txt">
              <div className="appname">DRAG<em>&</em>PLAY</div>
              <div className="apptag">DJ Bulk Downloader · YT · SC · Bandcamp · TikTok · Mixcloud</div>
            </div>
            <div className="hdr-stats">
              <div className="hpill"><strong className="g">{totalAll+done}</strong>total DL</div>
              <div className="hpill"><strong className="b">{tracks.length}</strong>in queue</div>
              {totalDuration>0 && <div className="hpill"><strong className="p">{fmtDurLong(totalDuration)}</strong>runtime</div>}
            </div>
          </header>

          {/* PLAYLIST BANNER */}
          {playlistBanner && (
            <div className="pl-banner">
              <div className="pl-banner-icon">◈</div>
              <div className="pl-banner-info">
                <div className="pl-banner-title">{playlistBanner.platform} Playlist detected — {playlistBanner.count} tracks auto-expanded</div>
                <div className="pl-banner-sub">All tracks queued · ready to bulk download</div>
              </div>
              <button className="btn btn-ghost btn-sm" onClick={()=>setPlaylistBanner(null)}>×</button>
            </div>
          )}

          {/* DROP ZONE */}
          <div
            className={`dz ${over?"over":""} ${playlistBanner?"playlist":""}`}
            onDragOver={e=>{e.preventDefault();setOver(true)}}
            onDragLeave={()=>setOver(false)}
            onDrop={handleDrop}
            onClick={handleZoneClick}
          >
            <div className="dzi">{over?"↓":"⬇"}</div>
            <div className="dzt">{over?"Drop it — we'll handle the rest":"Drag links here"}</div>
            <div className="dzs">Single tracks · playlists · sets · albums</div>
            <div className="src-row">
              {[
                {n:"YouTube",c:"#ff3e3e"},{n:"SoundCloud",c:"#ff6b1a"},
                {n:"Bandcamp",c:"#2de0ff"},{n:"TikTok",c:"#ff2d78"},
                {n:"Mixcloud",c:"#ffd600"},{n:"Spotify",c:"#c6f135"},
              ].map(s=>(
                <span key={s.n} className="src">
                  <span className="dot" style={{background:s.c}} />{s.n}
                </span>
              ))}
            </div>
            <span className="pl-badge">◈ Paste playlist URL → all tracks download at once</span>
          </div>

          {/* PASTE AREA */}
          <div className="paste">
            <div className="paste-hdr">
              <span className="paste-lbl">// Paste URLs · one per line · playlists supported</span>
              <button className="btn btn-ghost btn-sm" onClick={()=>{
                navigator.clipboard.readText?.().then(t=>setPaste(p=>p?p+"\n"+t:t)).catch(()=>{});
              }}>Paste clipboard</button>
            </div>
            <textarea
              className="paste-ta"
              value={paste}
              onChange={e=>setPaste(e.target.value)}
              placeholder={"https://youtube.com/watch?v=...\nhttps://youtube.com/playlist?list=...\nhttps://soundcloud.com/artist/sets/my-set\nhttps://bandcamp.com/album/..."}
              onKeyDown={e=>{ if(e.key==="Enter"&&(e.metaKey||e.ctrlKey)){ e.preventDefault(); handlePasteAdd(); } }}
            />
            <div className="paste-foot">
              <span className="paste-foot-txt">
                {paste.split("\n").filter(l=>l.trim()).length} line(s) · ⌘↵ or Ctrl↵ to add
              </span>
              <button className="btn btn-ghost btn-sm" onClick={handlePasteAdd} disabled={!paste.trim()}>
                → Add to queue
              </button>
            </div>
          </div>

          {/* FORMAT + QUALITY */}
          <div className="fmt-row">
            <span className="fmt-lbl">Format:</span>
            {["MP3","WAV","FLAC","AIFF","M4A","OGG"].map(f=>(
              <button key={f} className={`fmtb ${fmt===f?"on":""}`} onClick={()=>setFmt(f)}>{f}</button>
            ))}
            {(fmt==="MP3"||fmt==="OGG") && <>
              <div className="fmt-sep"/>
              <span className="fmt-lbl">Quality:</span>
              {["128","192","256","320"].map(q=>(
                <button key={q} className={`fmtb ${qual===q?"on":""}`} onClick={()=>setQual(q)}>{q}k</button>
              ))}
            </>}
            {fmt==="FLAC" && <>
              <div className="fmt-sep"/>
              <span className="fmt-lbl">Depth:</span>
              {["16-bit","24-bit"].map(q=>(
                <button key={q} className={`fmtb ${qual===q?"on":""}`} onClick={()=>setQual(q)}>{q}</button>
              ))}
            </>}
          </div>

          {/* TABS */}
          <div className="tabs">
            <button className={`tab ${tab==="queue"?"on":""}`} onClick={()=>setTab("queue")}>
              Queue {tracks.length>0&&`(${tracks.length})`}
            </button>
            <button className={`tab ${tab==="history"?"on":""}`} onClick={()=>setTab("history")}>
              History {history.length>0&&`(${history.length})`}
            </button>
          </div>

          {tab==="queue" && (
            <>
              {/* TOTAL STATS BAR */}
              {tracks.length>0 && (
                <div className="total-bar">
                  <div className="tstat">
                    <div className="tstat-lbl">Total runtime</div>
                    <div className="tstat-val y">{fmtDurLong(totalDuration)}</div>
                  </div>
                  <div className="tstat">
                    <div className="tstat-lbl">Tracks queued</div>
                    <div className="tstat-val b">{queuedCount}</div>
                  </div>
                  <div className="tstat">
                    <div className="tstat-lbl">Est. download</div>
                    <div className="tstat-val g">{estimateDownloadTime(queuedCount,fmt,qual)}</div>
                  </div>
                  <div className="tstat">
                    <div className="tstat-lbl">Done</div>
                    <div className="tstat-val" style={{color:done>0?"var(--g)":"var(--muted)"}}>{done}</div>
                  </div>
                </div>
              )}

              {/* QUEUE CONTROLS */}
              {tracks.length>0 && (
                <div className="qctrl">
                  <div className="qctrl-l">
                    <span className="qtitle">Queue</span>
                    <span className="qcnt">{queued} queued · {done} done · {errors} err</span>
                  </div>
                  {done>0 && <button className="btn btn-ghost btn-sm" onClick={clearDone}>Clear done</button>}
                  <button className="btn btn-danger btn-sm" onClick={clearAll}>Clear all</button>
                </div>
              )}

              {/* TRACK LIST */}
              {tracks.length===0 ? (
                <div className="empty">
                  <div className="empty-icon">🎛</div>
                  <div className="empty-txt">Drop some links or paste URLs above</div>
                </div>
              ) : (
                <>
                  <div className="tracklist">
                    {tracks.map(t=>(
                      <div key={t.id} className={`track s-${t.status}`}>
                        <div className="track-prog" style={{width:`${t.progress}%`}} />
                        <div className="t-plat" style={{background:t.platform.bg,color:t.platform.color}}>
                          {t.platform.icon}
                        </div>
                        <div className="t-info">
                          <div className="t-name">{t.title}</div>
                          <div className="t-url">{t.fromPlaylist?`Playlist: ${t.fromPlaylist.slice(0,50)}…`:t.url}</div>
                        </div>
                        {t.duration && <div className="t-dur">{fmtDur(t.duration)}</div>}
                        <div className="t-meta">
                          {t.status==="queued"     && <span className="tbadge q">queued</span>}
                          {t.status==="analyzing"  && <span className="tbadge az">analyzing…</span>}
                          {t.status==="downloading"&& <span className="tbadge dl">↓ {t.progress}%</span>}
                          {t.status==="done" && <>
                            {t.bpm && <span className="tbadge bpm">{t.bpm}</span>}
                            {t.key && <span className="tbadge key">{t.key}</span>}
                            <span className="tbadge done">✓ {fmt}</span>
                          </>}
                          {t.status==="error" && <span className="tbadge err">✕ failed</span>}
                          <button className="t-rm" onClick={()=>removeTrack(t.id)}>×</button>
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* BIG DOWNLOAD ALL BUTTON */}
                  {queuedCount>0 && (
                    <button
                      className="dl-all-btn"
                      style={{
                        background: running?"var(--panel2)":"var(--g)",
                        color: running?"var(--muted)":"var(--black)",
                        cursor: running?"not-allowed":"pointer",
                        border: running?"1px solid var(--border)":"none",
                      }}
                      onClick={startAll}
                      disabled={running}
                    >
                      <span style={{fontSize:18}}>⬇</span>
                      {running
                        ? `Downloading… (${downloading} active)`
                        : `Download all  ${queuedCount} tracks  ·  ${fmt}${qual&&(fmt==="MP3"||fmt==="OGG")?" "+qual+"k":fmt==="FLAC"?" "+qual:""}`}
                      {!running && <span style={{opacity:.6,fontSize:11}}>· est. {estimateDownloadTime(queuedCount,fmt,qual)}</span>}
                    </button>
                  )}

                  {done>0 && !running && (
                    <div style={{display:"flex",gap:8}}>
                      <button className="btn btn-blue" style={{flex:1,justifyContent:"center",fontSize:11,padding:"12px"}}
                        onClick={()=>addNotif("Export to Rekordbox/Serato — v1.1","info")}>
                        → Export to DJ Library (Rekordbox/Serato)
                      </button>
                    </div>
                  )}
                </>
              )}
            </>
          )}

          {tab==="history" && (
            history.length===0 ? (
              <div className="empty"><div className="empty-icon">📂</div><div className="empty-txt">No history yet</div></div>
            ) : (
              <div className="tracklist">
                {history.map((h,i)=>(
                  <div key={i} className="track s-done">
                    <div className="t-plat" style={{background:"rgba(198,241,53,.1)",color:"var(--g)"}}>⊞</div>
                    <div className="t-info">
                      <div className="t-name">Session · {h.date}</div>
                      <div className="t-url">{h.count} tracks · {h.fmt}{h.qual&&(h.fmt==="MP3"||h.fmt==="OGG")?" "+h.qual+"k":""}</div>
                    </div>
                    <span className="tbadge done">✓ {h.count}</span>
                  </div>
                ))}
              </div>
            )
          )}

          <div className="footer">
            <span>DRAG&PLAY · DJ Bulk Downloader · v2.0</span>
            <span>yt-dlp engine · auto BPM+key · 3 parallel streams</span>
          </div>
        </div>
      </div>
    </>
  );
}

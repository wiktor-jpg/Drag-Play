// ─── Storage polyfill (in-memory, works everywhere) ───────────────────────────
const store = {};
window.storage = {
  get: async (k) => store[k] !== undefined ? { key: k, value: store[k] } : null,
  set: async (k, v) => { store[k] = String(v); return { key: k, value: String(v) }; },
  delete: async (k) => { delete store[k]; return { key: k, deleted: true }; },
  list: async (prefix) => ({
    keys: Object.keys(store).filter(k => !prefix || k.startsWith(prefix))
  }),
};

import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App />);
